﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public const string ConnectionString = "Server = 192.168.0.13; Database = DB1; User Id = thelastsw; Password = 1223334444";
        private void LoadData(string query)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }
        private void SequelWithoutReturn(string query)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
        private void DisplayStatistics()
        {
            string query = @"SELECT MAX(PriceSub) As MaxCost,
                                    AVG(PriceSub) As AvgCost,
                                    SUM(PriceSub) As TotalCost FROM Subscriptions";
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            decimal maxCost = Convert.ToDecimal(reader["MaxCost"]);
                            decimal avgCost = Convert.ToDecimal(reader["AvgCost"]);
                            decimal totalCost = Convert.ToDecimal(reader["TotalCost"]);

                            label1.Text = $"Максимальная стоимость: {maxCost}";
                            label4.Text = $"Средняя стоимость: {avgCost}";
                            label8.Text = $"Полная стоимость всех товаров: {totalCost}";
                        }
                    }
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
            FillComboBoxes();
        }
        private void Increment()
        {
            LoadData("DECLARE @maxIdReceipt INT;SELECT @maxIdReceipt = MAX(IdReceipt) FROM Receipts;");
        }
        private void FillComboBoxes()
        {
            string query = "SELECT NameCoach FROM Coaches";
            comboBox8.Items.Clear();
            comboBox20.Items.Clear();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string NameCoach = Convert.ToString(reader["NameCoach"]);
                            ComboBoxItem item = new ComboBoxItem()
                            {
                                Item = NameCoach
                            };
                            comboBox8.Items.Add(item);
                            comboBox20.Items.Add(item);
                        }
                    }
                }
            }
            query = "SELECT SpecCoach FROM Coaches";
            comboBox10.Items.Clear();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string SpecCoach = Convert.ToString(reader["SpecCoach"]);
                            ComboBoxItem item = new ComboBoxItem()
                            {
                                Item = SpecCoach
                            };
                            comboBox10.Items.Add(item);
                        }
                    }
                }
            }
            query = "SELECT IdTrain FROM Subscriptions";
            comboBox2.Items.Clear();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string IdTrain = Convert.ToString(reader["IdTrain"]);
                            ComboBoxItem item = new ComboBoxItem()
                            {
                                Item = IdTrain
                            };
                            comboBox2.Items.Add(item);
                        }
                    }
                }
            }
            query = "SELECT DurationSub FROM Subscriptions";
            comboBox3.Items.Clear();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string DurationSub = Convert.ToString(reader["DurationSub"]);
                            ComboBoxItem item = new ComboBoxItem()
                            {
                                Item = DurationSub
                            };
                            comboBox3.Items.Add(item);
                        }
                    }
                }
            }
            query = "SELECT PriceSub FROM Subscriptions";
            comboBox5.Items.Clear();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string PriceSub = Convert.ToString(reader["PriceSub"]);
                            ComboBoxItem item = new ComboBoxItem()
                            {
                                Item = PriceSub
                            };
                            comboBox5.Items.Add(item);
                        }
                    }
                }
            }
            query = "SELECT IdSub FROM Subscriptions";
            comboBox6.Items.Clear();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string IdSub = Convert.ToString(reader["IdSub"]);
                            ComboBoxItem item = new ComboBoxItem()
                            {
                                Item = IdSub
                            };
                            comboBox6.Items.Add(item);
                        }
                    }
                }
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            LoadData("select DurationSub, PriceSub from dbo.Subscriptions");
            DisplayStatistics();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string IdTrain = comboBox1.Text;
            string DurationSub = textBox3.Text;
            string PriceSub = textBox5.Text;
            SequelWithoutReturn($"insert into dbo.Subscriptions (IdTrain, DurationSub, PriceSub) values ('{IdTrain}', '{DurationSub}', '{PriceSub}') ");
            LoadData("select IdSub, IdTrain, DurationSub, PriceSub from dbo.Subscriptions");
        }

        private void button2_Click(object sender, EventArgs e)
        { 
            string IdTrain = comboBox2.Text;
            string DurationSub = comboBox3.Text;
            string PriceSub = comboBox5.Text;
            SequelWithoutReturn($"update dbo.Subscriptions set DurationSub = '{DurationSub}', PriceSub = '{PriceSub}' where IdTrain = '{IdTrain}'");
            LoadData("select IdSub, IdTrain, DurationSub, PriceSub from dbo.Subscriptions");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string IdSub = comboBox6.Text;
            SequelWithoutReturn($"delete from dbo.Subscriptions where IdSub = '{IdSub}'");
            LoadData("select IdSub, IdTrain, DurationSub, PriceSub from dbo.Subscriptions");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            LoadData("select upper(NameCoach) as 'NameCoach', DateCoach, SpecCoach, GenderCoach from dbo.Coaches");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string NameCoach = textBox7.Text;
            string DateCoach = textBox8.Text;
            string SpecCoach = textBox9.Text;
            string GenderCoach = textBox10.Text;
            SequelWithoutReturn($"insert into dbo.Coaches (NameCoach, DateCoach, SpecCoach, GenderCoach) values ('{NameCoach}', '{DateCoach}', '{SpecCoach}', '{GenderCoach}') ");
            LoadData("select upper(NameCoach) as 'NameCoach', DateCoach, SpecCoach, GenderCoach from dbo.Coaches");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string NameCoach = comboBox8.Text;
            string SpecCoach = comboBox10.Text;
            SequelWithoutReturn($"update dbo.Coaches set SpecCoach = '{SpecCoach}' where NameCoach = '{NameCoach}'");
            LoadData("select upper(NameCoach), DateCoach, SpecCoach, GenderCoach from dbo.Coaches");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string NameCoach = comboBox20.Text;
            SequelWithoutReturn($"delete from dbo.Coaches where NameCoach = '{NameCoach}'");
            LoadData("select upper(NameCoach) as 'NameCoach', DateCoach, SpecCoach, GenderCoach from dbo.Coaches");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            LoadData("select TrainName, Coaches.NameCoach from dbo.Trainings " +
                "right join Coaches on Coaches.IdCoach = Trainings.IdCoach");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string IdCoach = textBox12.Text;
            SequelWithoutReturn($"insert into dbo.Trainings (IdCoach) values ('{IdCoach}') ");
            LoadData("select IdTrain as 'Train Numb', Coaches.NameCoach from dbo.Trainings " +
                "right join Coaches on Coaches.IdCoach = Trainings.IdCoach");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            LoadData("select IdSub, SurnameConsumer, DiscountReceipt, DateReceipt from dbo.Receipts");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string IdSub = textBox14.Text;
            string SurnameConsumer = textBox15.Text;
            string DiscountReceipt = textBox17.Text;
            string DateReceipt = textBox18.Text;
            SequelWithoutReturn($"DECLARE @maxIdReceipt INT;SELECT @maxIdReceipt = MAX(IdReceipt) FROM Receipts;" +
                $"insert into dbo.Receipts (IdReceipt, IdSub, SurnameConsumer, DiscountReceipt, DateReceipt) values (@maxIdReceipt+1,'{IdSub}', '{SurnameConsumer}', '{DiscountReceipt}', '{DateReceipt}') ");
            LoadData("select IdSub, SurnameConsumer, DiscountReceipt, DateReceipt from dbo.Receipts");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            LoadData("select NameCoach, DateCoach, SpecCoach, GenderCoach from dbo.Coaches order by DateCoach");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            LoadData("select IdSub, IdTrain, DurationSub, PriceSub from dbo.Subscriptions where DurationSub > 2");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoadData("(SELECT 'Subscriptons' AS Source, IdSub AS Name, PriceSub AS Value FROM Subscriptions) UNION (SELECT 'Receipts' AS Source, NULL AS Name, DateReceipt AS Value FROM Receipts)");
        }

    }
    public class ComboBoxItem
    {
        public string Item { get; set; }
        public override string ToString()
        {
            return Item;
        }
    }

}
